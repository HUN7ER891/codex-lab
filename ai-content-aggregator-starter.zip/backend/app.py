from flask import Flask

app = Flask(__name__)

@app.route('/')
def index():
    return "AI Content Aggregator backend running!"

if __name__ == "__main__":
    app.run(debug=True, port=5000)
